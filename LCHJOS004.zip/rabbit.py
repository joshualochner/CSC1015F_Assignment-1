# Prints out ascii art of rabbits
# Joshua Lochner
# 25 February 2018

print("(\\\               (\\/)      ",sep="")
print("( '')    (\\_/)   (.. )   //)",sep="")
print("O(\")(\") (\\\'.\'/) (\")(\")O (\" )",sep="")
print("        (\")_(\")        ()()o",sep="")